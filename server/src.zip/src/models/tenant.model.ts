export interface Tenant {
    id: number;
    name: string;
    nit: string | null;
    createdAt: Date;
}